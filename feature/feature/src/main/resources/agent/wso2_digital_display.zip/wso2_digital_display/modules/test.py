__author__ = 'lasantha'
import admin_panel
import time
start_time = time.time()

obj = admin_panel.DisplayAdmin()

print obj.get_device_status()



